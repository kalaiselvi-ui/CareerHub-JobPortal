import { Routes, Route } from "react-router-dom";
import MainLayout from "./layouts/MainLayout.tsx";
import { lazy, Suspense } from "react";
import LoadingSpinner from "./components/common/LoadingSpinner.tsx";
import Register from "./pages/auth/Register.tsx";
import Login from "./pages/auth/Login.tsx";
import ForgotPassword from "./pages/auth/ForgotPassword.tsx";
import ResetPassword from "./pages/auth/ResetPassword.tsx";
import { Toaster } from "react-hot-toast";
import GuestRoute from "./components/routes/GuestRoute.tsx";
import AdminDashboard from "./pages/admin/AdminDashboard.tsx";
import ProtectedRoutes from "./components/routes/ProtectedRoutes.tsx";
import { CreateJob } from "./pages/job-management/CreateJob.tsx";
import ManageJobs from "./pages/job-management/ManageJobs.tsx";
import { EditJob } from "./pages/job-management/EditJob.tsx";
import ManageCategories from "./pages/admin/category-management/ManageCategories.tsx";
import ManageUsers from "./pages/admin/user/ManageUsers.tsx";
import AdminProfile from "./pages/admin/Profile.tsx";
import RecruiterDashboard from "./pages/recruiter/Dashboard.tsx";
import MyJobsPage from "./pages/recruiter/MyJobs.tsx";
import ApplyJobPage from "./components/application/ApplyJob.tsx";
import CandidateDashboard from "./pages/candidate/Dashboard.tsx";
import MyApplications from "./pages/candidate/MyApplications.tsx";
import CandidateProfile from "./pages/candidate/Profile.tsx";
import { RecruiterApplications } from "./pages/recruiter/Application.tsx";

const Home = lazy(() => import("./pages/Home.tsx"));
const Jobs = lazy(() => import("./pages/Jobs.tsx"));
const About = lazy(() => import("./pages/About.tsx"));
const Companies = lazy(() => import("./pages/Companies.tsx"));

const App = () => {
  return (
    <>
      <Suspense fallback={<LoadingSpinner />}>
        <Routes>
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Home />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/jobs/:id" element={<Jobs />} />
            <Route element={<GuestRoute />}>
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route
                path="/reset-password/:token"
                element={<ResetPassword />}
              />
            </Route>
            <Route path="/companies" element={<Companies />} />
            <Route path="/about" element={<About />} />
            <Route element={<ProtectedRoutes allowedRoles={["admin"]} />}>
              <Route path="/admin/dashboard" element={<AdminDashboard />} />
            </Route>
            <Route
              element={
                <ProtectedRoutes allowedRoles={["admin", "recruiter"]} />
              }
            >
              <Route path="/jobs/manage" element={<ManageJobs />} />
              <Route path="/jobs/create" element={<CreateJob />} />
              <Route path="/jobs/:id/edit" element={<EditJob />} />
            </Route>

            <Route element={<ProtectedRoutes allowedRoles={["recruiter"]} />}>
              <Route
                path="/recruiter/dashboard"
                element={<RecruiterDashboard />}
              />
              <Route path="/recruiter/jobs" element={<MyJobsPage />} />
              <Route
                path="/recruiter/my-applications"
                element={<RecruiterApplications />}
              />
            </Route>
            <Route path="/jobs/:jobId/apply" element={<ApplyJobPage />} />

            <Route element={<ProtectedRoutes allowedRoles={["candidate"]} />}>
              <Route
                path="/candidate/dashboard"
                element={<CandidateDashboard />}
              />
              <Route
                path="/candidate/my-applications"
                element={<MyApplications />}
              />
              <Route path="/candidate/profile" element={<CandidateProfile />} />
            </Route>

            <Route element={<ProtectedRoutes allowedRoles={["admin"]} />}>
              <Route path="/categories/manage" element={<ManageCategories />} />
              <Route path="/categories/" element={<ManageCategories />} />
              <Route path="/users/manage" element={<ManageUsers />} />
            </Route>
            <Route path="/profile" element={<AdminProfile />} />
            <Route path="*" element={<div>404 - Page Not Found</div>} />
          </Route>
        </Routes>
      </Suspense>
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 3000,
        }}
      />
    </>
  );
};

export default App;
