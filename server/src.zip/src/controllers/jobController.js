import { uploadImageToCloudinary } from "../../utils/uploadImage.js";
import Job from "../models/job.model.js";

export const createJob = async (req, res) => {
  try {
    const {
      title,
      description,
      company,
      location,
      salary,
      skills,
      jobType,
      category,
      experienceLevel,
      workMode,
      applicationDeadline,
      responsibilities,
      requirements,
      status,
    } = req.body;
    const { id, role } = req.user;
    if (
      !title ||
      !description ||
      !company ||
      !location ||
      !skills ||
      !salary?.currency ||
      salary?.min == null ||
      salary?.max == null ||
      !salary?.period
    ) {
      return res
        .status(400)
        .json({ success: false, message: "Required Fields" });
    }

    const companyLogo = req.file
      ? await uploadImageToCloudinary(req.file.buffer)
      : null;
    const job = await Job.create({
      title,
      description,
      company,
      location,
      salary,
      skills,
      jobType,
      applicationDeadline,
      status,
      category,
      workMode,
      responsibilities: responsibilities || [],
      requirements: requirements || [],
      experienceLevel,
      companyLogo: companyLogo?.secure_url,
      createdBy: id,
    });

    return res.status(201).json({
      success: true,
      message: "New Job Created Successfully",
      data: job,
    });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export const getAllJob = async (req, res) => {
  try {
    const { search, location, jobType, workMode, experienceLevel } = req.query;
    const filter = {};
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: "i" } },
        { company: { $regex: search, $options: "i" } },
      ];
    }
    if (location) {
      filter.location = { $regex: location, $options: "i" };
    }
    if (jobType) {
      filter.jobType = jobType;
    }
    if (workMode) {
      filter.workMode = workMode;
    }
    if (experienceLevel) {
      filter.experienceLevel = experienceLevel;
    }
    const jobs = await Job.find(filter)
      .populate("createdBy", "name email")
      .sort({ createdAt: -1 });
    if (!jobs) {
      return res.status(404).json({ message: "Job not found" });
    }

    return res
      .status(200)
      .json({ message: "Successfully fetched all jobs", data: jobs });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export const getJobById = async (req, res) => {
  try {
    const { id } = req.params;
    const job = await Job.findById(id).populate("createdBy", "name email");
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    return res
      .status(200)
      .json({ success: true, message: "got the jobs by id", data: job });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export const updateJob = async (req, res) => {
  try {
    const {
      title,
      description,
      company,
      location,
      category,
      salary,
      skills,
      jobType,
      experienceLevel,
      workMode,
      applicationDeadline,
      responsibilities,
      requirements,
      status,
    } = req.body;

    const { id: userId, role } = req.user;

    const { id: jobId } = req.params;
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({ message: "Job not Found" });
    }

    if (role === "recruiter") {
      if (!job.createdBy) {
        return res.status(403).json({
          success: false,
          message: "You cannot delete this job",
        });
      }

      if (job.createdBy.toString() !== userId) {
        return res.status(403).json({
          success: false,
          message: "You cannot delete this job",
        });
      }
    }

    job.title = title ?? job.title;
    job.description = description ?? job.description;
    job.company = company ?? job.company;
    job.location = location ?? job.location;
    job.salary = salary ?? job.salary;
    job.skills = skills ?? job.skills;
    job.status = status ?? job.status;
    job.category = category ?? job.category;
    job.applicationDeadline = applicationDeadline ?? job.applicationDeadline;
    job.jobType = jobType ?? job.jobType;
    job.experienceLevel = experienceLevel ?? job.experienceLevel;
    job.workMode = workMode ?? job.workMode;
    job.responsibilities = responsibilities ?? job.responsibilities;
    job.requirements = requirements ?? job.requirements;

    if (req.file) {
      const companyLogo = await uploadImageToCloudinary(req.file.buffer);
      job.companyLogo = companyLogo.secure_url;
    }

    await job.save();
    return res
      .status(200)
      .json({ success: true, message: "Updated Job Successfully", data: job });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export const deleteJob = async (req, res) => {
  try {
    const { id: userId, role } = req.user;

    const { id: jobId } = req.params;
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        message: "Job not found",
      });
    }
    // Recruiters can delete only their own jobs
    if (role === "recruiter") {
      if (!job.createdBy) {
        return res.status(403).json({
          success: false,
          message: "You cannot delete this job",
        });
      }

      if (job.createdBy.toString() !== userId) {
        return res.status(403).json({
          success: false,
          message: "You cannot delete this job",
        });
      }
    }
    await job.deleteOne();
    return res.status(200).json({
      success: true,
      message: "Job deleted successfully",
    });
  } catch (err) {
    console.log(err);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

export const getMyJobs = async (req, res) => {
  try {
    const { id: userId, role } = req.user;

    // 1. Role verification
    if (role !== "recruiter") {
      return res.status(403).json({
        success: false,
        message: "Only recruiters can view their posted jobs",
      });
    }

    // 2. Query jobs created by this recruiter and populate the User model
    const jobs = await Job.find({ createdBy: userId }).populate({
      path: "createdBy",
      select: "name email role", // Fields to retrieve from the User model (exclude sensitive data like password)
    });

    return res.status(200).json({
      success: true,
      count: jobs.length,
      message: "Recruiter jobs retrieved successfully",
      data: jobs,
    });
  } catch (err) {
    console.error("Error in getMyJobs:", err);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};
