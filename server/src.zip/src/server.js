import "dotenv/config";

import express from "express";
import cors from "cors";
import connectDB from "./config/db.js";
import jobRoutes from "./routes/jobRoutes.js";
import applicationRoutes from "./routes/applicationRoutes.js";
import categoryRoutes from "./routes/categoryRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import userRoutes from "./routes/userRoutes.js";
import candidateProfileRoutes from "./routes/candidateRoutes.js";

const app = express();
const PORT = process.env.PORT || 3000;

app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "https://career-hub-job-portal-tau.vercel.app",
    ],
    credentials: true,
  }),
);
app.use(express.json()); // To parse JSON bodies sent by the frontend
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// Connect to Database
connectDB();

app.use("/api/auth", authRoutes);
app.use("/api/category", categoryRoutes);
app.use("/api/jobs", jobRoutes);
app.use("/api/applications", applicationRoutes);
app.use("/api/users", userRoutes);
app.use("/api/candidate", candidateProfileRoutes);

app.listen(PORT, () => {
  console.log(`server is running on http://localhost:${PORT}`);
});
